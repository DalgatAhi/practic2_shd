alert("Я JavaScript");
